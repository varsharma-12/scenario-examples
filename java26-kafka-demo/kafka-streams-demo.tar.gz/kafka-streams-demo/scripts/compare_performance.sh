#!/bin/bash

# Performance Comparison Script
# Collects metrics from both JDK 21 and JDK 26 deployments

set -e

echo "======================================"
echo "Java GC Performance Comparison"
echo "======================================"
echo ""

# Function to get metrics from a service
get_metrics() {
    local service=$1
    local namespace=${2:-default}
    
    echo "Collecting metrics from $service..."
    
    # Get pod name
    POD=$(kubectl get pods -n $namespace -l app=stock-processor,version=$service -o jsonpath='{.items[0].metadata.name}')
    
    if [ -z "$POD" ]; then
        echo "Error: No pod found for $service"
        return 1
    fi
    
    # Forward port temporarily
    kubectl port-forward -n $namespace $POD 8081:8080 &
    PF_PID=$!
    sleep 3
    
    # Fetch Prometheus metrics
    METRICS=$(curl -s http://localhost:8081/metrics)
    
    # Parse key metrics
    echo "$METRICS" | grep -E "trade_processing_time|jvm_gc_pause|jvm_memory_used" > /tmp/${service}_metrics.txt
    
    # Kill port-forward
    kill $PF_PID 2>/dev/null || true
    
    echo "✓ Metrics collected for $service"
}

# Function to analyze GC logs
analyze_gc_logs() {
    local service=$1
    local namespace=${2:-default}
    
    echo "Analyzing GC logs for $service..."
    
    POD=$(kubectl get pods -n $namespace -l app=stock-processor,version=$service -o jsonpath='{.items[0].metadata.name}')
    
    # Copy GC log from pod
    kubectl cp -n $namespace $POD:/tmp/gc.log /tmp/${service}_gc.log 2>/dev/null || echo "No GC log available yet"
    
    if [ -f /tmp/${service}_gc.log ]; then
        # Parse GC statistics
        echo "GC Pause Statistics:"
        grep "Pause" /tmp/${service}_gc.log | tail -100 | awk '{print $NF}' | sed 's/ms//' | \
        awk '{sum+=$1; sumsq+=$1*$1; if(NR==1){min=max=$1}} 
             {if($1<min) min=$1; if($1>max) max=$1} 
             END {print "  Average:", sum/NR "ms"; 
                  print "  Min:", min "ms"; 
                  print "  Max:", max "ms"; 
                  print "  StdDev:", sqrt(sumsq/NR - (sum/NR)^2) "ms"}'
    fi
}

# Function to check health probe failures
check_health() {
    local service=$1
    local namespace=${2:-default}
    
    echo "Checking health probe status for $service..."
    
    POD=$(kubectl get pods -n $namespace -l app=stock-processor,version=$service -o jsonpath='{.items[0].metadata.name}')
    
    # Get events related to readiness probe failures
    FAILURES=$(kubectl get events -n $namespace --field-selector involvedObject.name=$POD | grep "Readiness probe failed" | wc -l)
    
    echo "  Readiness probe failures: $FAILURES"
}

# Function to get resource utilization
get_resource_usage() {
    local service=$1
    local namespace=${2:-default}
    
    echo "Resource utilization for $service:"
    
    POD=$(kubectl get pods -n $namespace -l app=stock-processor,version=$service -o jsonpath='{.items[0].metadata.name}')
    
    kubectl top pod -n $namespace $POD 2>/dev/null || echo "  Metrics server not available"
}

# Main comparison
echo "Starting performance comparison..."
echo "Duration: 5 minutes"
echo ""

# Wait for initial warmup
echo "Warming up (30 seconds)..."
sleep 30

echo ""
echo "======================================"
echo "JDK 21 Metrics"
echo "======================================"
get_metrics "jdk21"
analyze_gc_logs "jdk21"
check_health "jdk21"
get_resource_usage "jdk21"

echo ""
echo "======================================"
echo "JDK 26 Metrics"
echo "======================================"
get_metrics "jdk26"
analyze_gc_logs "jdk26"
check_health "jdk26"
get_resource_usage "jdk26"

echo ""
echo "======================================"
echo "Comparison Summary"
echo "======================================"

# Generate comparison report
cat > /tmp/comparison_report.txt << EOF
Performance Comparison Report
Generated: $(date)

Key Metrics:

JDK 21:
$(cat /tmp/jdk21_metrics.txt 2>/dev/null | head -20)

JDK 26:
$(cat /tmp/jdk26_metrics.txt 2>/dev/null | head -20)

To view detailed metrics:
- JDK 21: cat /tmp/jdk21_metrics.txt
- JDK 26: cat /tmp/jdk26_metrics.txt

To view GC logs:
- JDK 21: cat /tmp/jdk21_gc.log
- JDK 26: cat /tmp/jdk26_gc.log
EOF

cat /tmp/comparison_report.txt

echo ""
echo "Full report saved to: /tmp/comparison_report.txt"
