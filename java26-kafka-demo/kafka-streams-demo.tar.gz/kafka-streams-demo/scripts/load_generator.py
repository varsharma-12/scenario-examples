#!/usr/bin/env python3
"""
Stock Trade Load Generator
Generates realistic stock trade data to Kafka for testing
"""

import json
import random
import time
from datetime import datetime
from kafka import KafkaProducer
import sys

# Stock symbols to simulate
SYMBOLS = [
    'AAPL', 'GOOGL', 'MSFT', 'AMZN', 'TSLA', 
    'META', 'NVDA', 'JPM', 'V', 'WMT',
    'DIS', 'NFLX', 'BA', 'GS', 'GE'
]

def generate_trade():
    """Generate a realistic stock trade"""
    symbol = random.choice(SYMBOLS)
    base_price = {
        'AAPL': 175.0, 'GOOGL': 140.0, 'MSFT': 375.0,
        'AMZN': 150.0, 'TSLA': 250.0, 'META': 350.0,
        'NVDA': 500.0, 'JPM': 150.0, 'V': 250.0,
        'WMT': 160.0, 'DIS': 95.0, 'NFLX': 450.0,
        'BA': 200.0, 'GS': 380.0, 'GE': 110.0
    }
    
    price = base_price[symbol] * (1 + random.uniform(-0.05, 0.05))
    volume = random.randint(100, 10000)
    
    trade = {
        'symbol': symbol,
        'price': round(price, 2),
        'volume': volume,
        'timestamp': datetime.now().isoformat(),
        'exchange': random.choice(['NYSE', 'NASDAQ']),
        'type': random.choice(['BUY', 'SELL'])
    }
    
    return json.dumps(trade)

def main():
    kafka_server = sys.argv[1] if len(sys.argv) > 1 else 'localhost:9092'
    rate = int(sys.argv[2]) if len(sys.argv) > 2 else 1000  # messages per second
    
    print(f"Connecting to Kafka at {kafka_server}")
    print(f"Target rate: {rate} messages/second")
    
    producer = KafkaProducer(
        bootstrap_servers=kafka_server,
        value_serializer=lambda v: v.encode('utf-8'),
        compression_type='snappy',
        batch_size=16384,
        linger_ms=10
    )
    
    print("Starting load generation...")
    
    messages_sent = 0
    start_time = time.time()
    
    try:
        while True:
            batch_start = time.time()
            
            # Send messages in batches to achieve target rate
            for _ in range(rate // 10):  # 10 batches per second
                trade = generate_trade()
                producer.send('stock-trades', value=trade)
                messages_sent += 1
                
                if messages_sent % 1000 == 0:
                    elapsed = time.time() - start_time
                    current_rate = messages_sent / elapsed
                    print(f"Sent {messages_sent} messages | Rate: {current_rate:.0f} msg/s")
            
            # Sleep to maintain target rate
            batch_duration = time.time() - batch_start
            sleep_time = max(0, 0.1 - batch_duration)  # 100ms per batch
            time.sleep(sleep_time)
            
    except KeyboardInterrupt:
        print("\nStopping load generation...")
    finally:
        producer.flush()
        producer.close()
        
        total_time = time.time() - start_time
        avg_rate = messages_sent / total_time
        print(f"\nTotal messages sent: {messages_sent}")
        print(f"Average rate: {avg_rate:.0f} messages/second")

if __name__ == '__main__':
    main()
