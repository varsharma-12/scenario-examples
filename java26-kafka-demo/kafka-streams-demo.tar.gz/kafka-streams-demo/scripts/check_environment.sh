#!/bin/bash

# Environment Verification Script
# Checks if all prerequisites are installed and configured

set +e  # Don't exit on errors, we want to check everything

echo "╔════════════════════════════════════════════════════════╗"
echo "║   Java GC Performance Demo - Environment Check         ║"
echo "╚════════════════════════════════════════════════════════╝"
echo ""

# Color codes
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Track if all checks pass
ALL_PASSED=true

# Function to check command existence
check_command() {
    local cmd=$1
    local name=$2
    local install_hint=$3
    
    if command -v $cmd &> /dev/null; then
        echo -e "${GREEN}✓${NC} $name installed"
        return 0
    else
        echo -e "${RED}✗${NC} $name not found"
        if [ -n "$install_hint" ]; then
            echo -e "  ${YELLOW}→${NC} $install_hint"
        fi
        ALL_PASSED=false
        return 1
    fi
}

# Function to check version
check_version() {
    local cmd=$1
    local name=$2
    local min_version=$3
    
    if command -v $cmd &> /dev/null; then
        version=$($cmd --version 2>&1 | head -1)
        echo -e "${GREEN}✓${NC} $name: $version"
        return 0
    else
        return 1
    fi
}

echo "Checking prerequisites..."
echo ""

# Check Docker
echo "1. Docker"
if check_command docker "Docker" "Install from https://docs.docker.com/get-docker/"; then
    docker version > /dev/null 2>&1
    if [ $? -eq 0 ]; then
        echo -e "  ${GREEN}✓${NC} Docker daemon is running"
    else
        echo -e "  ${RED}✗${NC} Docker daemon is not running"
        echo -e "  ${YELLOW}→${NC} Start Docker Desktop or run: sudo systemctl start docker"
        ALL_PASSED=false
    fi
fi
echo ""

# Check Kubernetes
echo "2. Kubernetes"
if check_command kubectl "kubectl" "Install from https://kubernetes.io/docs/tasks/tools/"; then
    kubectl cluster-info > /dev/null 2>&1
    if [ $? -eq 0 ]; then
        echo -e "  ${GREEN}✓${NC} kubectl can connect to cluster"
        context=$(kubectl config current-context 2>/dev/null)
        echo -e "  ${GREEN}→${NC} Current context: $context"
    else
        echo -e "  ${RED}✗${NC} kubectl cannot connect to cluster"
        echo -e "  ${YELLOW}→${NC} Enable Kubernetes in Docker Desktop or configure kubectl"
        ALL_PASSED=false
    fi
fi
echo ""

# Check Maven
echo "3. Maven"
if check_command mvn "Maven" "Install from https://maven.apache.org/install.html"; then
    check_version mvn "Maven" "3.6"
fi
echo ""

# Check Python
echo "4. Python"
if check_command python3 "Python" "Install from https://www.python.org/downloads/"; then
    check_version python3 "Python" "3.8"
    
    # Check pip
    if command -v pip3 &> /dev/null || command -v pip &> /dev/null; then
        echo -e "  ${GREEN}✓${NC} pip is installed"
        
        # Check kafka-python
        python3 -c "import kafka" > /dev/null 2>&1
        if [ $? -eq 0 ]; then
            echo -e "  ${GREEN}✓${NC} kafka-python library installed"
        else
            echo -e "  ${YELLOW}!${NC} kafka-python not installed (can be installed later)"
            echo -e "  ${YELLOW}→${NC} Run: pip install kafka-python"
        fi
    else
        echo -e "  ${YELLOW}!${NC} pip not found"
        echo -e "  ${YELLOW}→${NC} Install pip: python3 -m ensurepip"
    fi
fi
echo ""

# Check available resources
echo "5. System Resources"
if command -v docker &> /dev/null; then
    # Check Docker resources
    echo -e "  Checking Docker resource limits..."
    
    # This works on Docker Desktop
    memory_gb=$(docker system info 2>/dev/null | grep "Total Memory" | awk '{print $3}')
    cpus=$(docker system info 2>/dev/null | grep "CPUs" | awk '{print $2}')
    
    if [ -n "$memory_gb" ]; then
        echo -e "  ${GREEN}→${NC} Memory: ${memory_gb}GiB"
        # Check if enough memory (need at least 8GB)
        memory_value=$(echo $memory_gb | sed 's/GiB//')
        if (( $(echo "$memory_value < 6" | bc -l) )); then
            echo -e "  ${YELLOW}!${NC} Low memory - recommend at least 8GB for Docker"
        fi
    fi
    
    if [ -n "$cpus" ]; then
        echo -e "  ${GREEN}→${NC} CPUs: $cpus"
        if [ "$cpus" -lt 4 ]; then
            echo -e "  ${YELLOW}!${NC} Low CPU count - recommend at least 4 CPUs"
        fi
    fi
else
    echo -e "  ${YELLOW}!${NC} Cannot check resources (Docker not available)"
fi
echo ""

# Check disk space
echo "6. Disk Space"
available_gb=$(df -h . | tail -1 | awk '{print $4}')
echo -e "  Available: $available_gb"
echo ""

# Summary
echo "════════════════════════════════════════════════════════"
if [ "$ALL_PASSED" = true ]; then
    echo -e "${GREEN}✓ All required tools are installed!${NC}"
    echo ""
    echo "You're ready to run the demo. Next steps:"
    echo "  1. mvn clean package"
    echo "  2. docker build -f Dockerfile.jdk21 -t stock-processor:jdk21 ."
    echo "  3. docker build -f Dockerfile.jdk26 -t stock-processor:jdk26 ."
    echo "  4. kubectl apply -f k8s/"
    echo ""
    echo "Or run: ./scripts/run_demo.sh (if available)"
else
    echo -e "${RED}✗ Some prerequisites are missing${NC}"
    echo ""
    echo "Please install missing tools and try again."
    echo "See SETUP.md for detailed installation instructions."
fi
echo "════════════════════════════════════════════════════════"
