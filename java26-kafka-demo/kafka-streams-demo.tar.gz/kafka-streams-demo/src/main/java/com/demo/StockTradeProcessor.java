package com.demo;

import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.kstream.*;
import org.apache.kafka.streams.state.Stores;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.micrometer.core.instrument.*;
import io.micrometer.prometheus.PrometheusConfig;
import io.micrometer.prometheus.PrometheusMeterRegistry;

import java.time.Duration;
import java.util.Properties;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Stock Trade Processing Application
 * Simulates high-throughput financial data streaming with memory-intensive operations
 */
public class StockTradeProcessor {
    
    private static final ObjectMapper mapper = new ObjectMapper();
    private static final PrometheusMeterRegistry prometheusRegistry = 
        new PrometheusMeterRegistry(PrometheusConfig.DEFAULT);
    
    private static final AtomicLong messagesProcessed = new AtomicLong(0);
    private static final Timer processingTimer = prometheusRegistry.timer("trade.processing.time");
    
    public static void main(String[] args) {
        
        // Register GC metrics
        new com.sun.management.GarbageCollectionNotificationInfo();
        
        Properties props = new Properties();
        props.put(StreamsConfig.APPLICATION_ID_CONFIG, "stock-trade-processor");
        props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, 
                  System.getenv().getOrDefault("KAFKA_BOOTSTRAP", "localhost:9092"));
        props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass());
        props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass());
        
        // Optimize for throughput
        props.put(StreamsConfig.NUM_STREAM_THREADS_CONFIG, "4");
        props.put(StreamsConfig.COMMIT_INTERVAL_MS_CONFIG, "100");
        props.put(StreamsConfig.CACHE_MAX_BYTES_BUFFERING_CONFIG, "10485760"); // 10MB
        
        StreamsBuilder builder = new StreamsBuilder();
        
        // Input stream of stock trades
        KStream<String, String> trades = builder.stream("stock-trades");
        
        // Process trades with memory-intensive operations
        KStream<String, String> processedTrades = trades
            .mapValues(value -> {
                Timer.Sample sample = Timer.start(prometheusRegistry);
                try {
                    // Simulate complex processing with object creation (generates garbage)
                    JsonNode trade = mapper.readTree(value);
                    
                    // Memory-intensive calculations
                    double price = trade.get("price").asDouble();
                    int volume = trade.get("volume").asInt();
                    
                    // Create multiple objects to stress GC
                    StringBuilder analysis = new StringBuilder();
                    for (int i = 0; i < 100; i++) {
                        analysis.append("Analysis-").append(i).append(":");
                        analysis.append(price * volume * Math.random()).append(";");
                    }
                    
                    // Calculate trade value and risk metrics
                    double tradeValue = price * volume;
                    double volatility = calculateVolatility(price, volume);
                    
                    messagesProcessed.incrementAndGet();
                    
                    return String.format("{\"symbol\":\"%s\",\"value\":%.2f,\"volatility\":%.4f,\"analysis\":\"%s\"}", 
                                       trade.get("symbol").asText(), 
                                       tradeValue, 
                                       volatility,
                                       analysis.toString());
                } catch (Exception e) {
                    return value;
                } finally {
                    sample.stop(processingTimer);
                }
            });
        
        // Aggregate trades by symbol with windowing
        KTable<Windowed<String>, Long> tradeCounts = trades
            .selectKey((key, value) -> {
                try {
                    return mapper.readTree(value).get("symbol").asText();
                } catch (Exception e) {
                    return "UNKNOWN";
                }
            })
            .groupByKey()
            .windowedBy(TimeWindows.ofSizeWithNoGrace(Duration.ofSeconds(10)))
            .count(Materialized.as(Stores.inMemoryWindowStore("trade-counts", 
                                  Duration.ofMinutes(5), 
                                  Duration.ofSeconds(10), 
                                  false)));
        
        // Output processed trades
        processedTrades.to("processed-trades");
        
        // Start metrics endpoint
        startMetricsServer();
        
        // Build and start the streams application
        KafkaStreams streams = new KafkaStreams(builder.build(), props);
        
        // Add shutdown hook
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            streams.close();
            System.out.println("Application shut down gracefully");
        }));
        
        streams.start();
        
        // Print metrics periodically
        new Thread(() -> {
            while (true) {
                try {
                    Thread.sleep(5000);
                    printMetrics();
                } catch (InterruptedException e) {
                    break;
                }
            }
        }).start();
    }
    
    private static double calculateVolatility(double price, int volume) {
        // Simulate complex calculation that creates temporary objects
        double sum = 0;
        for (int i = 0; i < 1000; i++) {
            double[] prices = new double[100];
            for (int j = 0; j < 100; j++) {
                prices[j] = price * (1 + Math.random() * 0.1);
            }
            sum += calculateStdDev(prices);
        }
        return sum / 1000;
    }
    
    private static double calculateStdDev(double[] values) {
        double mean = 0;
        for (double v : values) mean += v;
        mean /= values.length;
        
        double variance = 0;
        for (double v : values) {
            variance += Math.pow(v - mean, 2);
        }
        return Math.sqrt(variance / values.length);
    }
    
    private static void startMetricsServer() {
        // Simple HTTP server for Prometheus metrics
        try {
            com.sun.net.httpserver.HttpServer server = 
                com.sun.net.httpserver.HttpServer.create(
                    new java.net.InetSocketAddress(8080), 0);
            
            server.createContext("/metrics", exchange -> {
                String response = prometheusRegistry.scrape();
                exchange.sendResponseHeaders(200, response.getBytes().length);
                java.io.OutputStream os = exchange.getResponseBody();
                os.write(response.getBytes());
                os.close();
            });
            
            server.createContext("/health", exchange -> {
                String response = "{\"status\":\"UP\"}";
                exchange.sendResponseHeaders(200, response.getBytes().length);
                java.io.OutputStream os = exchange.getResponseBody();
                os.write(response.getBytes());
                os.close();
            });
            
            server.setExecutor(null);
            server.start();
            System.out.println("Metrics server started on port 8080");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private static void printMetrics() {
        long processed = messagesProcessed.get();
        double avgLatency = processingTimer.mean(java.util.concurrent.TimeUnit.MILLISECONDS);
        double p99Latency = processingTimer.max(java.util.concurrent.TimeUnit.MILLISECONDS);
        
        System.out.printf("Messages Processed: %d | Avg Latency: %.2fms | P99: %.2fms%n", 
                         processed, avgLatency, p99Latency);
    }
}
