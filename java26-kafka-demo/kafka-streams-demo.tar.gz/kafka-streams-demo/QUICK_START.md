# Quick Reference: Running the Performance Demo

## One-Command Setup (Local Kubernetes)

```bash
# Clone/navigate to project directory
cd kafka-streams-demo

# Build everything
mvn clean package && \
docker build -f Dockerfile.jdk21 -t stock-processor:jdk21 . && \
docker build -f Dockerfile.jdk26 -t stock-processor:jdk26 . && \
kubectl apply -f k8s/

# Wait for everything to be ready
kubectl wait --for=condition=ready pod --all --timeout=300s

# Start load generation
pip install kafka-python && \
python3 scripts/load_generator.py kafka.default.svc.cluster.local:9092 1000
```

## Quick Metric Checks

### Watch Live Processing

```bash
# Terminal 1: JDK 21
kubectl logs -f -l version=jdk21 | grep "Messages Processed"

# Terminal 2: JDK 26  
kubectl logs -f -l version=jdk26 | grep "Messages Processed"
```

### Check GC Pauses

```bash
# JDK 21 GC pauses
kubectl logs -l version=jdk21 | grep "GC pause" | tail -20

# JDK 26 GC pauses
kubectl logs -l version=jdk26 | grep "GC pause" | tail -20
```

### Get Current Metrics

```bash
# JDK 21 metrics
kubectl port-forward svc/stock-processor-jdk21 8081:8080 &
curl -s http://localhost:8081/metrics | grep -E "trade_processing|jvm_gc"

# JDK 26 metrics
kubectl port-forward svc/stock-processor-jdk26 8082:8080 &
curl -s http://localhost:8082/metrics | grep -E "trade_processing|jvm_gc"
```

### Resource Usage

```bash
# CPU and Memory usage
kubectl top pods -l app=stock-processor
```

### Health Check Status

```bash
# Check for readiness probe failures
kubectl get events --sort-by='.lastTimestamp' | grep "Readiness probe failed"
```

## Expected Output Examples

### Good Performance (JDK 26)
```
Messages Processed: 59123 | Avg Latency: 24.18ms | P99: 78.34ms
[GC pause (G1 Evacuation Pause) 8.123ms]
```

### Baseline Performance (JDK 21)
```
Messages Processed: 56842 | Avg Latency: 38.42ms | P99: 156.23ms
[GC pause (G1 Evacuation Pause) 24.567ms]
```

## Common Issues

### Kafka Not Ready
```bash
# Check Kafka status
kubectl get pods -l app=kafka
kubectl logs kafka-0

# Restart if needed
kubectl delete pod kafka-0
```

### Application Not Processing
```bash
# Check application logs
kubectl logs -l app=stock-processor --tail=50

# Restart application
kubectl rollout restart deployment/stock-processor-jdk21
kubectl rollout restart deployment/stock-processor-jdk26
```

### No Metrics
```bash
# Verify metrics endpoint
kubectl exec -it $(kubectl get pod -l version=jdk21 -o name | head -1) -- \
  curl localhost:8080/metrics
```

## Clean Up

```bash
# Delete everything
kubectl delete -f k8s/

# Remove images
docker rmi stock-processor:jdk21 stock-processor:jdk26
```

## 5-Minute Demo Script

Perfect for presentations:

```bash
# 1. Deploy (1 min)
kubectl apply -f k8s/ && kubectl wait --for=condition=ready pod --all --timeout=180s

# 2. Start load (30 sec)
python3 scripts/load_generator.py kafka:9092 1000 &

# 3. Watch metrics (3 min) - Show side by side
# Terminal 1
kubectl logs -f -l version=jdk21 | grep "Messages Processed"

# Terminal 2  
kubectl logs -f -l version=jdk26 | grep "Messages Processed"

# 4. Show comparison (30 sec)
./scripts/compare_performance.sh
```

## Key Metrics to Highlight

| What to Show | Why It Matters |
|-------------|----------------|
| **Messages/sec** | Throughput improvement |
| **P99 Latency** | Tail latency reduction |
| **GC pause times** | Stop-the-world reduction |
| **CPU usage** | Resource efficiency |
| **Probe failures** | Operational stability |

## Stress Test

```bash
# Crank up the load to see bigger differences
python3 scripts/load_generator.py kafka:9092 5000
```

Expected behavior:
- JDK 21: Starts dropping messages, lag builds up
- JDK 26: Handles load smoothly, minimal lag
