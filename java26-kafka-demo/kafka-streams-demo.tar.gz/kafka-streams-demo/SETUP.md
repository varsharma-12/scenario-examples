# Java 26 GC Performance Demo - Setup Guide

## Prerequisites

- Docker Desktop with Kubernetes enabled, OR
- Minikube, OR
- Access to a Kubernetes cluster
- kubectl configured
- Maven 3.6+
- Python 3.8+ (for load generator)

## Quick Start

### Step 1: Build the Application

```bash
cd kafka-streams-demo

# Build the Java application
mvn clean package

# Build Docker images
docker build -f Dockerfile.jdk21 -t stock-processor:jdk21 .
docker build -f Dockerfile.jdk26 -t stock-processor:jdk26 .
```

### Step 2: Deploy to Kubernetes

```bash
# Deploy Kafka and Zookeeper
kubectl apply -f k8s/kafka.yaml

# Wait for Kafka to be ready
kubectl wait --for=condition=ready pod -l app=kafka --timeout=300s

# Deploy both versions of the application
kubectl apply -f k8s/deployment-jdk21.yaml
kubectl apply -f k8s/deployment-jdk26.yaml

# Verify deployments
kubectl get pods
```

Expected output:
```
NAME                                     READY   STATUS    RESTARTS   AGE
kafka-0                                  1/1     Running   0          2m
zookeeper-0                              1/1     Running   0          2m
stock-processor-jdk21-xxxx               1/1     Running   0          1m
stock-processor-jdk26-xxxx               1/1     Running   0          1m
```

### Step 3: Generate Load

```bash
# Install Python dependencies
pip install kafka-python

# Get Kafka service endpoint
KAFKA_ENDPOINT=$(kubectl get svc kafka -o jsonpath='{.spec.clusterIP}'):9092

# Start load generation (1000 messages/second)
python3 scripts/load_generator.py $KAFKA_ENDPOINT 1000
```

### Step 4: Monitor Performance

Open multiple terminal windows:

**Terminal 1 - JDK 21 Logs:**
```bash
kubectl logs -f deployment/stock-processor-jdk21
```

**Terminal 2 - JDK 26 Logs:**
```bash
kubectl logs -f deployment/stock-processor-jdk26
```

**Terminal 3 - Performance Comparison:**
```bash
# Wait 5 minutes for steady state, then run comparison
chmod +x scripts/compare_performance.sh
./scripts/compare_performance.sh
```

### Step 5: View Metrics

Access Prometheus metrics from each service:

**JDK 21:**
```bash
kubectl port-forward svc/stock-processor-jdk21 8081:8080
curl http://localhost:8081/metrics
```

**JDK 26:**
```bash
kubectl port-forward svc/stock-processor-jdk26 8082:8080
curl http://localhost:8082/metrics
```

## What to Look For

### Key Metrics to Compare

1. **Processing Latency**
   - Metric: `trade_processing_time_seconds`
   - Look for: Lower average and P99 latency in JDK 26

2. **GC Pause Times**
   - Check application logs for GC pause messages
   - Look for: Shorter and less frequent pauses in JDK 26

3. **Throughput**
   - Messages processed per second (shown in logs)
   - Look for: Higher throughput in JDK 26

4. **Readiness Probe Failures**
   - Check Kubernetes events
   - Look for: Fewer probe failures in JDK 26

5. **CPU Utilization**
   - Use `kubectl top pods`
   - Look for: Lower CPU usage in JDK 26

## Expected Results

Based on G1GC improvements in newer JDK versions:

| Metric | JDK 21 | JDK 26 (Expected) | Improvement |
|--------|--------|-------------------|-------------|
| Avg GC Pause | ~15ms | ~8ms | 47% |
| P99 Latency | ~85ms | ~45ms | 47% |
| Throughput | ~950 msg/s | ~990 msg/s | 4% |
| CPU Usage | ~1.8 cores | ~1.6 cores | 11% |
| Probe Failures/hr | 12-15 | 2-3 | 80% |

## Visualizing Results

### Create a Simple Dashboard

```bash
# Extract metrics for visualization
kubectl port-forward svc/stock-processor-jdk21 8081:8080 &
kubectl port-forward svc/stock-processor-jdk26 8082:8080 &

# Collect metrics every 10 seconds for 5 minutes
for i in {1..30}; do
  echo "Sample $i:"
  curl -s http://localhost:8081/metrics | grep trade_processing_time | tail -1
  curl -s http://localhost:8082/metrics | grep trade_processing_time | tail -1
  sleep 10
done
```

## Cleanup

```bash
# Delete all resources
kubectl delete -f k8s/deployment-jdk21.yaml
kubectl delete -f k8s/deployment-jdk26.yaml
kubectl delete -f k8s/kafka.yaml

# Remove Docker images
docker rmi stock-processor:jdk21 stock-processor:jdk26
```

## Troubleshooting

### Pods not starting
```bash
kubectl describe pod <pod-name>
kubectl logs <pod-name>
```

### Kafka connection issues
```bash
# Check Kafka is ready
kubectl exec -it kafka-0 -- kafka-topics --list --bootstrap-server localhost:9092

# Create topics manually if needed
kubectl exec -it kafka-0 -- kafka-topics --create --topic stock-trades --bootstrap-server localhost:9092
kubectl exec -it kafka-0 -- kafka-topics --create --topic processed-trades --bootstrap-server localhost:9092
```

### No metrics available
```bash
# Check if metrics endpoint is accessible
kubectl exec -it <pod-name> -- curl localhost:8080/metrics
```

## Advanced: Stress Testing

Increase load to see more dramatic GC differences:

```bash
# High load - 5000 messages/second
python3 scripts/load_generator.py $KAFKA_ENDPOINT 5000

# Monitor GC activity
kubectl logs -f <jdk21-pod> | grep "GC pause"
kubectl logs -f <jdk26-pod> | grep "GC pause"
```

## Understanding the Code

The application intentionally creates memory pressure to stress the GC:

1. **Object Creation**: Each message creates 100+ temporary objects
2. **Complex Calculations**: Volatility calculation creates arrays and performs 1000+ iterations
3. **Windowed Aggregations**: Kafka Streams maintains state in memory
4. **String Operations**: StringBuilder concatenation creates garbage

This simulates real-world data streaming workloads where:
- JSON parsing/serialization creates objects
- Business logic performs calculations
- State stores maintain windowed aggregates
- Network buffers allocate/deallocate memory
